#!/usr/bin/env python3
print('I' + 'love' + 'Python.')

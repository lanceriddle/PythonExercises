#!/usr/bin/env python3
version = 3
print('I love Python {}.'.format(version))

#!/usr/bin/env python3
sentence = 'She said, "That is a great tasting apple!"'

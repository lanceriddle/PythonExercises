#!/usr/bin/env python3
happiness = 'happy ' * 3
print(happiness)

#!/usr/bin/env python3
print('{0:8} | {1:<8}'.format('Fruit', 'Quantity'))
print('{0:8} | {1:<8.2f}'.format('Apple', 2.33333))
print('{0:8} | {1:<8.2f}'.format('Oranges', 10))

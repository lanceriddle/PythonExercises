#!/usr/bin/env python3
fruit = 'apple'
print(len(fruit))

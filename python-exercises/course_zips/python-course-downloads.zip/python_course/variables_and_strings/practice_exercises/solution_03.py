#!/usr/bin/env python3
text = input('What would you like the cat to say? ')
text_length = len(text)

print('            {}'.format('_' * text_length))
print('          < {} >'.format(text))
print('            {}'.format('-' * text_length))
print('          /')
print(' /\_/\   /')
print('( o.o )')
print(' > ^ <')

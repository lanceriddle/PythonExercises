#!/usr/bin/env python3

animals = ['man', 'bear', 'pig']
animals.append('cow')
print(animals[-1])

#!/usr/bin/env python3

animals = ['man', 'bear', 'pig']
animals.extend(['cow', 'duck'])
print(animals)

more_animals = ['horse', 'dog']
animals.extend(more_animals)
print(animals)

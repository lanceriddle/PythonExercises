#!/usr/bin/env python3

for number in range(1, 10, 2):
    print(number)

#!/usr/bin/env python3

animals = ['man', 'bear', 'pig']
print(animals[0])
print(animals[1])
print(animals[2])

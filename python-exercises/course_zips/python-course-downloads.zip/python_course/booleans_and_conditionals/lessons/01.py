#!/usr/bin/env python3

a_boolean = True
the_other_boolean = False
print(a_boolean)
print(the_other_boolean)

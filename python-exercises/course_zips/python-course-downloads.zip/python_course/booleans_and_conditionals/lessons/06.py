#!/usr/bin/env python3

age = 31
if age >= 35:
    print('You are old enough to be a Senator or the President.')
elif age >= 30:
    print('You are old enough to be a Senator.')
else:
    print('You are not old enough to be a Senator or the President.')

print('Have a nice day!')

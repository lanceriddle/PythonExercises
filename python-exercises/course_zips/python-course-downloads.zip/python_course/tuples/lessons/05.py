#!/usr/bin/env python3

days_of_the_week = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
(mon, tue, wed, thr, fri, sat, sun) = days_of_the_week
print(mon)
print(fri)

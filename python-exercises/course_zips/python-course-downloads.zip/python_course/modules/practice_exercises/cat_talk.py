#!/usr/bin/env python3

import cat_say


def main():
    cat_say.cat_say('Feed me.')
    cat_say.cat_say('Pet me.')
    cat_say.cat_say('Purr.  Purr.')

if __name__ == '__main__':
    main()

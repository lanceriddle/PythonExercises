#!/usr/bin/env python3

import sys
sys.path.append('/Users/jason/python')
for path in sys.path:
    print(path)

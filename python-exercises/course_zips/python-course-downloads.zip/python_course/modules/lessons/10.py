#!/usr/bin/env python3

import say_hi3
say_hi3.say_hi()

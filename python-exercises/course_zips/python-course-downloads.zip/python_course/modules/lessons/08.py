#!/usr/bin/env python3

import say_hi
say_hi.say_hi()

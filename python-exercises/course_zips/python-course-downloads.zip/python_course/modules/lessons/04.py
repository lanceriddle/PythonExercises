#!/usr/bin/env python3

from time import *
print(timezone)
print(asctime())
sleep(3)
print(asctime())

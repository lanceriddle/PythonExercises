#!/usr/bin/env python3

contacts = {
    'Jason': '555-0123',
    'Carl': '555-0987'
}
for contact in contacts:
    print('The number for {0} is {1}.'.format(contact, contacts[contact]))

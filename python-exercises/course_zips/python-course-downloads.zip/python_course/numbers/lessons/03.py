#!/usr/bin/env python3

sum = 1 + 2
difference = 100 - 1
new_number = sum + difference
print(new_number)
print(sum / sum)
print(sum + 1)

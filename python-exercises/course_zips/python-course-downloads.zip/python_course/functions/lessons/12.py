#!/usr/bin/env python3


def is_odd(number):
    """Determine if a number is odd."""
    if number % 2 == 0:
        return False
    else:
        return True

print(is_odd(7))

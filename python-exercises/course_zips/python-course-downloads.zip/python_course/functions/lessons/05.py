#!/usr/bin/env python3


def say_hi(name):
    print('Hi {}!'.format(name))

say_hi()
